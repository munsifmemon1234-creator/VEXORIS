(() => {
  const PRICES = {
    starter: { name: "Starter Website", amount: 25000 },
    business: { name: "Business Website", amount: 60000 },
    custom: { name: "Custom Web Solution", amount: null }
  };

  const money = value =>
    value === null || value === undefined
      ? "Custom Quote"
      : `PKR ${Number(value).toLocaleString("en-PK")}`;

  const makeReference = () =>
    "VEX-" + Date.now().toString(36).toUpperCase().slice(-8);

  const getOrder = () => {
    try {
      return JSON.parse(localStorage.getItem("vexorisOrder") || "null");
    } catch {
      return null;
    }
  };

  const saveOrder = order => {
    localStorage.setItem("vexorisOrder", JSON.stringify(order));
  };

  // Checkout page
  const checkoutForm = document.getElementById("checkoutForm");
  if (checkoutForm) {
    const serviceSelect = document.getElementById("service");
    const summaryService = document.getElementById("summaryService");
    const summaryAmount = document.getElementById("summaryAmount");

    const params = new URLSearchParams(window.location.search);
    const requestedService = params.get("service");
    if (requestedService && PRICES[requestedService]) {
      serviceSelect.value = requestedService;
    }

    const updateSummary = () => {
      const item = PRICES[serviceSelect.value];
      summaryService.textContent = item ? item.name : "Not selected";
      summaryAmount.textContent = item ? money(item.amount) : "—";
    };

    serviceSelect.addEventListener("change", updateSummary);
    updateSummary();

    checkoutForm.addEventListener("submit", event => {
      event.preventDefault();

      const serviceKey = serviceSelect.value;
      const service = PRICES[serviceKey];
      if (!service) return;

      const order = {
        reference: makeReference(),
        customer: {
          name: document.getElementById("customerName").value.trim(),
          email: document.getElementById("customerEmail").value.trim(),
          phone: document.getElementById("customerPhone").value.trim()
        },
        serviceKey,
        serviceName: service.name,
        amount: service.amount,
        requirements: document.getElementById("requirements").value.trim(),
        createdAt: new Date().toISOString(),
        paymentStatus: service.amount === null ? "quote_required" : "pending"
      };

      saveOrder(order);

      if (service.amount === null) {
        window.location.href = "thank-you.html?type=quote";
      } else {
        window.location.href = "payment.html";
      }
    });
  }

  // Payment page
  const payButton = document.getElementById("payButton");
  if (payButton) {
    const order = getOrder();

    if (!order) {
      window.location.href = "checkout.html";
      return;
    }

    document.getElementById("orderReference").textContent = order.reference;
    document.getElementById("customerDisplay").textContent = order.customer.name;
    document.getElementById("serviceDisplay").textContent = order.serviceName;
    document.getElementById("totalDisplay").textContent = money(order.amount);

    if (order.amount === null) {
      document.getElementById("paymentArea").classList.add("hidden");
      document.getElementById("paymentUnavailable").classList.remove("hidden");
    } else {
      payButton.addEventListener("click", () => {
        // DEMO ONLY.
        // Replace this redirect with the approved Easypaisa gateway initiation
        // request once merchant credentials/API details are provided.
        order.paymentStatus = "demo_completed";
        order.paymentCompletedAt = new Date().toISOString();
        saveOrder(order);
        window.location.href = "thank-you.html?type=payment";
      });
    }
  }

  // Thank-you page
  const thankReference = document.getElementById("thankReference");
  if (thankReference) {
    const order = getOrder();
    const type = new URLSearchParams(window.location.search).get("type");

    if (!order) {
      thankReference.textContent = "—";
      return;
    }

    thankReference.textContent = order.reference;
    document.getElementById("thankService").textContent = order.serviceName;
    document.getElementById("thankAmount").textContent = money(order.amount);

    if (type === "quote" || order.amount === null) {
      document.getElementById("thankTitle").textContent = "Quote Request Received";
      document.getElementById("thankText").textContent =
        "Thank you. VEXORIS has received your custom project request. Our team will review your requirements and confirm the quotation before payment.";
    } else {
      document.getElementById("thankTitle").textContent = "Order Received";
      document.getElementById("thankText").textContent =
        "Thank you. Your VEXORIS service order has been recorded with the reference shown below.";
    }
  }
})();
